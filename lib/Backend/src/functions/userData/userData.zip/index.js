exports.handler = (event, context, callback) => {
    const data = json.stringify(event.userData)
    callback(null, data)
}