var jwt = require('jsonwebtoken')

exports.handler = (event, context, callback) => {
    const user = {
        user: event.user,
        party: event.party
    }
    jwt.sign({user}, 'lowkeysecret', (token) => {
        callback(token)
    })
}